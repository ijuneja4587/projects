from tkinter import *
import tkinter as ttk

def Train():
    """GUI"""
    import tkinter as tk
    import tkinter as ttk

    import numpy as np
    import pandas as pd
    from PIL import Image, ImageTk

    from sklearn.decomposition import PCA
    from sklearn.preprocessing import LabelEncoder

    root = tk.Tk()

    #root.geometry("800x850+0+0")
    root.title("Detect Disease")
    root.configure(background="purple")
    w, h = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry("%dx%d+0+0" % (w, h))
    
    image2 = Image.open('slide2.jpg')

    image2 = image2.resize((w, h), Image.ANTIALIAS)
    
    background_image = ImageTk.PhotoImage(image2)
    
    
    background_label = tk.Label(root, image=background_image)
    background_label.image = background_image
    background_label.place(x=0, y=0)  # , relwidth=1, relheight=1)

    
    #StationId = tk.StringVar()
    gender = tk.IntVar()
    Age = tk.IntVar()
    EDUC = tk.IntVar()
    SES = tk.IntVar()
    MMSE = tk.IntVar()
    CDR = tk.IntVar()
    eTIV = tk.IntVar()
    nWBV = tk.DoubleVar()
    ASF = tk.DoubleVar()
    
    
    #===============================================================================================



    def Detect():
       
    
        
        e1=gender.get()
        print(e1)
        
        e2=Age.get()
        print(e2)
        
        e3=EDUC.get()
        print(e3)
        #print(type(e3))
        e4=SES.get()
        print(e4)
        e5=MMSE.get()
        print(e5)
        e6=CDR.get()
        print(e6)
        e7=eTIV.get()
        print(e7)
        e8=nWBV.get()
        print(e8)
        e9=ASF.get()
        print(e9)
       
        #########################################################################################
        
        from joblib import dump , load
        a1=load('SVM_AD_MODEL.joblib')
        v= a1.predict([[e1,e2, e3, e4, e5, e6, e7, e8, e9]])
        print(v)
        if v[0]==0:
            print("Nondemented")
            l1 = tk.Label(root,text="Not Alzheimer's Disease Detect",background="Green",foreground="white",font=('times', 15, ' bold '),height=8,width=40)
            l1.place(x=900,y=150)
            file = open(r"D:/ashwini bitmap folder 2023/23C9434 - Alzheimer Disease IP (CNN and SVM)/100% code new/Alzheirmer-Disease-SVM (1)/Report.txt", 'w')
            file.write("-----Patient Report-----\n As per input data and system model No  Alzheimer's Disease Detected for Respective Paptient."
                       "\n\n***Relax and Follow below mentioned Life Style to be Healthy as You Are!!!***"
                    
                    )
            file.close()
            
        else:
            print("Demented")
            lab1 = tk.Label(root, text="Alzheimer's Disease Detect \n involves the use of biomarkers, \n such as genetic and imaging markers, \n to accurately diagnose and classify patients based \n on the specific subtype \n of the disease they have.", background="Red", foreground="white",font=('times', 15, ' bold '),height=8,width=40)
            lab1.place(x=900, y=150)
            file = open(r"D:/ashwini bitmap folder 2023/23C9434 - Alzheimer Disease IP (CNN and SVM)/100% code new/Alzheirmer-Disease-SVM (1)/Report.txt", 'w')
            file.write("-----Patient Report-----\n As per input data and system model  Alzheimer's Disease Detected for Respective Paptient."
                       "\n\n******alzheimer Follow Medicatins******"
                    
                    )
            file.close()

    
    frame_alpr = tk.LabelFrame(root, text=" --Disease Detection-- ", width=800, height=500, bd=5, font=('Algerian', 14, ' bold '),bg="white")
    frame_alpr.grid(row=0, column=0, sticky='nw')
    frame_alpr.place(x=100, y=100)


    l2=tk.Label(frame_alpr,text="Gender",background="black",fg="white",font=('times', 20, ' bold '),width=10)
    l2.place(x=50,y=30)
    sex=tk.Entry(frame_alpr,bd=2,width=5,font=("TkDefaultFont", 20),textvar=gender)
    sex.place(x=250,y=30)

    l3=tk.Label(frame_alpr,text="Age",background="black",fg="white",font=('times', 20, ' bold '),width=10)
    l3.place(x=50,y=80)
    chest_pain=tk.Entry(frame_alpr,bd=2,width=5,font=("TkDefaultFont", 20),textvar=Age)
    chest_pain.place(x=250,y=80)
    
    
   
    l4=tk.Label(frame_alpr,text="EDUC",background="black",fg="white",font=('times', 20, ' bold '),width=10)
    l4.place(x=50,y=130)
    restbp=tk.Entry(frame_alpr,bd=2,width=5,font=("TkDefaultFont", 20),textvar=EDUC)
    restbp.place(x=250,y=130)

    l5=tk.Label(frame_alpr,text="SES",background="black",fg="white",font=('times', 20, ' bold '),width=10)
    l5.place(x=50,y=180)
    chol=tk.Entry(frame_alpr,bd=2,width=5,font=("TkDefaultFont", 20),textvar=SES)
    chol.place(x=250,y=180)

    l6=tk.Label(frame_alpr,text="MMSE",background="black",fg="white",font=('times', 20, ' bold '),width=10)
    l6.place(x=450,y=30)
    fbs=tk.Entry(frame_alpr,bd=2,width=5,font=("TkDefaultFont", 20),textvar=MMSE)
    fbs.place(x=650,y=30)

    l7=tk.Label(frame_alpr,text="CDR",background="black",fg="white",font=('times', 20, ' bold '),width=10)
    l7.place(x=450,y=80)
    restecg=tk.Entry(frame_alpr,bd=2,width=5,font=("TkDefaultFont", 20),textvar=CDR)
    restecg.place(x=650,y=80)

    l8=tk.Label(frame_alpr,text="eTIV",background="black",fg="white",font=('times', 20, ' bold '),width=10)
    l8.place(x=450,y=130)
    maxhr=tk.Entry(frame_alpr,bd=2,width=5,font=("TkDefaultFont", 20),textvar=eTIV)
    maxhr.place(x=650,y=130)

    l9=tk.Label(frame_alpr,text="nWBV",background="black",fg="white",font=('times', 20, ' bold '),width=10)
    l9.place(x=450,y=180)
    exang=tk.Entry(frame_alpr,bd=2,width=5,font=("TkDefaultFont", 20),textvar=nWBV)
    exang.place(x=650,y=180)

    l10=tk.Label(frame_alpr,text="ASF",background="black",fg="white",font=('times', 20, ' bold '),width=10)
    l10.place(x=450,y=230)
    oldpeak=tk.Entry(frame_alpr,bd=2,width=5,font=("TkDefaultFont", 20),textvar=ASF)
    oldpeak.place(x=650,y=230)

    

    button1 = tk.Button(frame_alpr,text="Submit",command=Detect,font=('times', 20, ' bold '),background='brown',width=10)
    button1.place(x=350,y=400)


    root.mainloop()

Train()