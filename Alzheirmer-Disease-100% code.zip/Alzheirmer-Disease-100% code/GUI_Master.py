import tkinter as tk
from tkinter import ttk, LEFT, END
from PIL import Image, ImageTk
from tkinter.filedialog import askopenfilename
from tkinter import messagebox as ms
import cv2
import sqlite3
import os
import numpy as np
import time
from tkvideo import tkvideo
'''import detection_emotion_practice as validate'''
#import video_capture as value
#import lecture_details as detail_data
#import video_second as video1

#import lecture_video  as video

global fn
fn = ""
##############################################+=============================================================
root = tk.Tk()
root.configure(background="#D15FEE")
# root.geometry("1300x700")


w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("%dx%d+0+0" % (w, h))
root.title("Alzheimer Disease")



#loading the images
img=ImageTk.PhotoImage(Image.open("al3.jpg"))

img2=ImageTk.PhotoImage(Image.open("al1.jpg"))

img3=ImageTk.PhotoImage(Image.open("al2.jpeg"))


logo_label=tk.Label()
logo_label.place(x=0,y=0)

x=1


# function to change to next image
def move():
    global x
    if x == 4:
            x = 1
    if x == 1:
        logo_label.config(image=img)
    elif x == 2:
        logo_label.config(image=img2)
    elif x == 3:
        logo_label.config(image=img3)
    x = x+1
    root.after(2000, move)
  
# calling the function
move()





#################################################################$%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

def shift():
    x1,y1,x2,y2 = canvas.bbox("marquee")
    if(x2<0 or y1<0): #reset the coordinates
        x1 = canvas.winfo_width()
        y1 = canvas.winfo_height()//2
        canvas.coords("marquee",x1,y1)
    else:
        canvas.move("marquee", -2, 0)
    canvas.after(1000//fps,shift)

canvas=tk.Canvas(root,bg="light blue")
canvas.pack()
canvas.place(x=0, y=0)
text_var="Alzheimer Disease"
text=canvas.create_text(0,-2000,text=text_var,font=('Raleway',25,'bold'),fill='white',tags=("marquee",),anchor='w')
x1,y1,x2,y2 = canvas.bbox("marquee")
width = 1600
height = 80
canvas['width']=width
canvas['height']=height
fps=40    #Change the fps to make the animation faster/slower
shift()   #Function Calling

################################$%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


#iframesrc = ("https://assets.pinterest.com/ext/embed.html?id=578853358377785481", height="1167", width="600" , frameborder="0", scrolling="no" )





# def cap_video():
    
#     video1.upload()
#     #from subprocess import call
#     #call(['python','video_second.py'])

def pre():
    from subprocess import call
    call(["python","train.py"])

def mas():
    from subprocess import call
    call(["python","GUI_Master1.py"])
    
 
    
def window():
  root.destroy()


button1 = tk.Button(root, text="CNN Prediction", command=mas, width=12, height=1,font=('times', 20, ' bold '), bg="#FFEBCD", fg="brown")
button1.place(x=1070, y=500)

button2 = tk.Button(root, text="SVM Prediction",command=pre,width=12, height=1,font=('times', 20, ' bold '), bg="#FFEBCD", fg="brown")
button2.place(x=1070, y=600)

button3 = tk.Button(root, text="EXIT",command=window,width=12, height=1,font=('times', 20, ' bold '), bg="#FFEBCD", fg="brown")
button3.place(x=1070, y=700)

root.mainloop()

